# mypackage
this library was created in Feb 2024 with Explore AI Data Science course

# How to install
...

